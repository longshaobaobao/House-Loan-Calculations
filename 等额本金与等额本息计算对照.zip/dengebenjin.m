function[zxt,allre] = dengebenjin(M,R,n)
M1=M*10000;%单位（万元）
R1=R*0.01;%年利率
n1=n*12;%期数
r=R1/12;%月利率
reben=M1/n1;
A=zeros(3,n1);

for i = 0:n1-1
    reli=((M1-i*reben))*r;
    A(1,i+1)=reben;
    A(2,i+1)=reli;
    A(3,i+1)=reben+reli;
end
allre=sum(A(3,:))
zxt=plot(1:n1,A(3,:),'-*g');
ylabel("每月还款金额")
fprintf("如果是等额本金，那么总计需要还款 %d元",allre);
end
