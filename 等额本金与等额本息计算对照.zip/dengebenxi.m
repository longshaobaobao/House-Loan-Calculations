function[remon,allre] = dengebenxi(M,R,n)
M1=M.*10000;%单位（万元）
R1=R*0.01;%年利率
n1=n*12;%期数
r=R1/12;%月利率
A=[0,0];
remon = M1*r*(1+r)^n1/((1+r)^n1-1);
A(1) = remon;
allre = remon * n1;
A(2) = allre;
fprintf("如果是等额本息，那么每个月还款%.2f，总计还款%.2f",A(1),A(2))
